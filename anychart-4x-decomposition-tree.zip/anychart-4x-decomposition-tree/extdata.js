define([], function() {
  return '=kjSTVFbaNjT2YkbUNDZtRVSWRlV5xGMWlXStdlTsVEV0gmRTNnRIJFRGdUZvpUaPl2aYplcKlXZ';
});
